<?php
/**
 * The main template file
 *

 */

get_header();
?>


	

<?php
get_footer();
